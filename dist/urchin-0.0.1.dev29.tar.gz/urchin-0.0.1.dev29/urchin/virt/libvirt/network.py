

class VIF(object):
    pass


class OVS(object):
    pass


class NIC(object):
    pass
